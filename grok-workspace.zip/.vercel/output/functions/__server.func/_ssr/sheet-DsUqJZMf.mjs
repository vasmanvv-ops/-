import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { h as cn } from "./router-BOojmBmH.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sheet-DsUqJZMf.js
var import_jsx_runtime = require_jsx_runtime();
function Sheet({ open, onOpenChange, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		shouldScaleBackground: false,
		noBodyStyles: true,
		modal: true,
		children: open ? children : null
	});
}
function SheetContent({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-50 bg-ink/40 no-print" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
		className: cn("fixed bottom-0 left-0 right-0 z-50 flex max-h-[92vh] flex-col rounded-t-xl bg-paper outline-none no-print", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 shrink-0 rounded-full bg-border" }), children]
	})] });
}
function SheetTitle({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
		className: cn("font-display text-xl font-medium tracking-tight", className),
		children
	});
}
function SheetDescription({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Description, {
		className: "text-sm text-fg-muted",
		children
	});
}
//#endregion
export { SheetTitle as i, SheetContent as n, SheetDescription as r, Sheet as t };
