import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Download } from "../_libs/lucide-react.mjs";
import { m as Button } from "./router-BOojmBmH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/install-banner-CWj_VQZm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useInstallPrompt() {
	const [event, setEvent] = (0, import_react.useState)(null);
	const [installed, setInstalled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(display-mode: standalone)").matches || "standalone" in navigator && Boolean(navigator.standalone)) {
			setInstalled(true);
			return;
		}
		const onPrompt = (raw) => {
			raw.preventDefault();
			setEvent(raw);
		};
		const onInstalled = () => {
			setInstalled(true);
			setEvent(null);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		window.addEventListener("appinstalled", onInstalled);
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.removeEventListener("appinstalled", onInstalled);
		};
	}, []);
	const install = async () => {
		if (!event) return false;
		await event.prompt();
		setEvent(null);
		return true;
	};
	return {
		canInstall: Boolean(event) && !installed,
		installed,
		install
	};
}
function InstallBanner() {
	const { canInstall, install } = useInstallPrompt();
	if (!canInstall) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-lg bg-cream px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-fg",
			children: "Установить на телефон как приложение"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			variant: "primary",
			onClick: () => void install(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Установить"]
		})]
	});
}
//#endregion
export { InstallBanner as t };
