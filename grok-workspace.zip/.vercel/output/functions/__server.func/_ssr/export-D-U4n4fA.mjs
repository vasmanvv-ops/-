import { a as formatMoney, r as CATEGORY_LABEL, u as computeLedger } from "./router-BOojmBmH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/export-D-U4n4fA.js
function ledgerToCsv(days) {
	const rows = [[
		"Дата",
		"Выручка",
		"Расходы итого",
		"Итог дня",
		"Баланс нарастающим",
		"Категория расхода",
		"Назначение",
		"Сумма расхода",
		"Заметка"
	]];
	for (const day of computeLedger(days)) {
		if (day.expenses.length === 0) {
			rows.push([
				day.date,
				formatMoney(day.revenue),
				formatMoney(day.expenseTotal),
				formatMoney(day.dayNet),
				formatMoney(day.runningBalance),
				"",
				"",
				"",
				day.note
			]);
			continue;
		}
		day.expenses.forEach((expense, index) => {
			rows.push([
				index === 0 ? day.date : "",
				index === 0 ? formatMoney(day.revenue) : "",
				index === 0 ? formatMoney(day.expenseTotal) : "",
				index === 0 ? formatMoney(day.dayNet) : "",
				index === 0 ? formatMoney(day.runningBalance) : "",
				CATEGORY_LABEL[expense.category],
				expense.title,
				formatMoney(expense.amount),
				index === 0 ? day.note : ""
			]);
		});
	}
	return rows.map((row) => row.map(csvCell).join(";")).join("\n");
}
function csvCell(value) {
	if (/[;"\n]/.test(value)) return `"${value.replaceAll("\"", "\"\"")}"`;
	return value;
}
function downloadText(filename, content, mime) {
	const blob = new Blob(["﻿" + content], { type: mime });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	link.remove();
	URL.revokeObjectURL(url);
}
function serializeLedger(days) {
	return JSON.stringify({
		version: 1,
		days
	}, null, 2);
}
function parseLedgerBackup(raw) {
	const parsed = JSON.parse(raw);
	const days = Array.isArray(parsed) ? parsed : parsed.days;
	if (!Array.isArray(days)) throw new Error("bad backup");
	return days.map((day) => ({
		id: String(day.id ?? crypto.randomUUID()),
		date: String(day.date),
		revenue: Number(day.revenue) || 0,
		note: String(day.note ?? ""),
		expenses: Array.isArray(day.expenses) ? day.expenses.map((expense) => ({
			id: String(expense.id ?? crypto.randomUUID()),
			category: expense.category === "supplies" || expense.category === "salary" ? expense.category : "other",
			title: String(expense.title ?? ""),
			amount: Number(expense.amount) || 0
		})) : []
	}));
}
//#endregion
export { serializeLedger as i, ledgerToCsv as n, parseLedgerBackup as r, downloadText as t };
