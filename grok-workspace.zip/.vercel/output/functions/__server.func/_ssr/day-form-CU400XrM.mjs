import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Plus, n as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as formatMoney, c as newId, h as cn, i as EXPENSE_CATEGORIES, l as parseMoney, m as Button, n as useLedgerStore, o as formatMoneySigned, p as todayIso, r as CATEGORY_LABEL, s as moneyToInput, u as computeLedger } from "./router-BOojmBmH.mjs";
import { n as Label, t as Input } from "./label-aAQWW89d.mjs";
import { i as SheetTitle, n as SheetContent, r as SheetDescription, t as Sheet } from "./sheet-DsUqJZMf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/day-form-CU400XrM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-20 w-full rounded-md border border-border bg-paper-raised px-3 py-2 text-base text-fg", "placeholder:text-fg-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var QUICK = [
	{
		category: "supplies",
		title: "Оплата поставки"
	},
	{
		category: "salary",
		title: "Зарплата"
	},
	{
		category: "other",
		title: "Аренда"
	},
	{
		category: "other",
		title: "Налоги"
	},
	{
		category: "other",
		title: "Коммунальные"
	},
	{
		category: "other",
		title: "Транспорт"
	}
];
function blankExpense(partial) {
	return {
		key: newId(),
		category: "supplies",
		title: "",
		amount: "",
		...partial
	};
}
function DayFormSheet() {
	const days = useLedgerStore((s) => s.days);
	const formOpen = useLedgerStore((s) => s.formOpen);
	const editingId = useLedgerStore((s) => s.editingId);
	const draftDate = useLedgerStore((s) => s.draftDate);
	const closeForm = useLedgerStore((s) => s.closeForm);
	const upsertDay = useLedgerStore((s) => s.upsertDay);
	const removeDay = useLedgerStore((s) => s.removeDay);
	const editing = days.find((day) => day.id === editingId);
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [revenue, setRevenue] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [expenses, setExpenses] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)(null);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!formOpen) return;
		setError(null);
		setConfirmDelete(false);
		if (editing) {
			setDate(editing.date);
			setRevenue(moneyToInput(editing.revenue));
			setNote(editing.note);
			setExpenses(editing.expenses.map((item) => ({
				key: item.id,
				category: item.category,
				title: item.title,
				amount: moneyToInput(item.amount)
			})));
			return;
		}
		setDate(draftDate || todayIso());
		setRevenue("");
		setNote("");
		setExpenses([]);
	}, [
		formOpen,
		editing,
		draftDate
	]);
	const revenueValue = parseMoney(revenue);
	const parsedExpenses = expenses.map((item) => ({
		...item,
		parsed: parseMoney(item.amount)
	}));
	const expenseTotal = parsedExpenses.reduce((sum, item) => sum + (item.parsed ?? 0), 0);
	const dayNet = (revenueValue ?? 0) - expenseTotal;
	const previewBalance = (0, import_react.useMemo)(() => {
		if (!formOpen) return 0;
		const draft = parsedExpenses.filter((item) => item.title.trim() && item.parsed !== null).map((item) => ({
			id: item.key,
			category: item.category,
			title: item.title.trim(),
			amount: item.parsed ?? 0
		}));
		const next = days.filter((day) => day.id !== editing?.id);
		next.push({
			id: editing?.id ?? "draft",
			date,
			revenue: revenueValue ?? 0,
			expenses: draft,
			note
		});
		return computeLedger(next).find((day) => day.date === date)?.runningBalance ?? 0;
	}, [
		formOpen,
		days,
		editing?.id,
		date,
		revenueValue,
		expenses,
		note,
		parsedExpenses
	]);
	const onSave = () => {
		if (revenueValue === null) {
			setError("Проверьте сумму выручки.");
			return;
		}
		const built = [];
		for (const item of expenses) {
			if (!item.title.trim() && !item.amount.trim()) continue;
			const amount = parseMoney(item.amount);
			if (!item.title.trim() || amount === null) {
				setError("У каждого расхода укажите название и сумму.");
				return;
			}
			built.push({
				id: item.key,
				category: item.category,
				title: item.title.trim(),
				amount
			});
		}
		const result = upsertDay({
			date,
			revenue: revenueValue,
			expenses: built,
			note: note.trim()
		}, editing?.id);
		if (!result.ok) {
			setError(result.error);
			return;
		}
		toast.success(editing ? "День обновлён" : "День записан");
	};
	const onDelete = () => {
		if (!editing) return;
		if (!confirmDelete) {
			setConfirmDelete(true);
			return;
		}
		removeDay(editing.id);
		toast.success("Запись удалена");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: formOpen,
		onOpenChange: (open) => !open ? closeForm() : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "px-5 pb-3 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: editing ? "Правка дня" : "Новый день" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Выручка, расходы и баланс считаются сразу. На одну дату — одна запись." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 space-y-4 overflow-y-auto px-5 pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "day-date",
									children: "Дата"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "day-date",
									type: "date",
									value: date,
									onChange: (event) => setDate(event.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "day-revenue",
									children: "Выручка, ₽"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "day-revenue",
									inputMode: "decimal",
									placeholder: "0",
									value: revenue,
									onChange: (event) => setRevenue(event.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Расходы" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										variant: "ghost",
										onClick: () => setExpenses((list) => [...list, blankExpense()]),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Строка"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5",
									children: QUICK.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-8 rounded-full border border-border bg-paper-raised px-3 text-xs text-fg-muted",
										onClick: () => setExpenses((list) => [...list, blankExpense(item)]),
										children: item.title
									}, item.title))
								}),
								expenses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rounded-md bg-cream/70 px-3 py-3 text-sm text-fg-muted",
									children: "Поставки, зарплата и прочие траты — каждая отдельной строкой, с назначением."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2",
									children: expenses.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "rounded-lg border border-border bg-paper-raised p-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
													className: "h-11 min-w-0 flex-1 rounded-md border border-border bg-paper px-2 text-sm text-fg",
													value: item.category,
													onChange: (event) => setExpenses((list) => list.map((row) => row.key === item.key ? {
														...row,
														category: event.target.value
													} : row)),
													"aria-label": "Категория расхода",
													children: EXPENSE_CATEGORIES.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: category,
														children: CATEGORY_LABEL[category]
													}, category))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													inputMode: "decimal",
													className: "w-28 shrink-0",
													placeholder: "Сумма",
													value: item.amount,
													onChange: (event) => setExpenses((list) => list.map((row) => row.key === item.key ? {
														...row,
														amount: event.target.value
													} : row)),
													"aria-label": "Сумма расхода"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													size: "icon",
													variant: "ghost",
													"aria-label": "Удалить расход",
													onClick: () => setExpenses((list) => list.filter((row) => row.key !== item.key)),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											className: "mt-2",
											placeholder: "Назначение: поставка, ФИО, аренда…",
											value: item.title,
											onChange: (event) => setExpenses((list) => list.map((row) => row.key === item.key ? {
												...row,
												title: event.target.value
											} : row)),
											"aria-label": "Назначение расхода"
										})]
									}, item.key))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "day-note",
								children: "Заметка"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "day-note",
								rows: 2,
								placeholder: "Необязательно",
								value: note,
								onChange: (event) => setNote(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg bg-ink px-4 py-3 text-fg-on-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "space-y-1.5 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-cream/70",
											children: "Выручка"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular-nums",
											children: formatMoney(revenueValue ?? 0)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-cream/70",
											children: "Расходы"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular-nums",
											children: formatMoney(expenseTotal)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4 border-t border-cream/15 pt-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Итог дня" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: cn("tabular-nums", dayNet > 0 && "text-pine-soft", dayNet < 0 && "text-brick-soft"),
											children: formatMoneySigned(dayNet)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Баланс после дня" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-medium tabular-nums",
											children: formatMoney(previewBalance)
										})]
									})
								]
							})
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-brick",
							children: error
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 border-t border-border px-5 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
					children: [
						editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "shrink-0",
							onClick: onDelete,
							children: confirmDelete ? "Удалить?" : "Удалить"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: closeForm,
							children: "Отмена"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "primary",
							className: "flex-1",
							onClick: onSave,
							children: "Сохранить"
						})
					]
				})
			]
		}) })
	});
}
//#endregion
export { DayFormSheet };
