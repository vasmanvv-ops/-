import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { m as Button, n as useLedgerStore } from "./router-BOojmBmH.mjs";
import { i as SheetTitle, n as SheetContent, r as SheetDescription, t as Sheet } from "./sheet-DsUqJZMf.mjs";
import { i as serializeLedger, n as ledgerToCsv, r as parseLedgerBackup, t as downloadText } from "./export-D-U4n4fA.mjs";
import { t as InstallBanner } from "./install-banner-CWj_VQZm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-sheet-I4u23OR0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MoreSheet({ open, onOpenChange }) {
	const days = useLedgerStore((s) => s.days);
	const loadDemo = useLedgerStore((s) => s.loadDemo);
	const clearAll = useLedgerStore((s) => s.clearAll);
	const replaceAll = useLedgerStore((s) => s.replaceAll);
	const fileRef = (0, import_react.useRef)(null);
	const exportJson = () => {
		downloadText("kassovaya-kniga.json", serializeLedger(days), "application/json");
		toast.success("Файл книги сохранён");
	};
	const exportCsv = () => {
		downloadText("kassovaya-kniga.csv", ledgerToCsv(days), "text/csv;charset=utf-8");
		toast.success("Таблица выгружена");
	};
	const onImport = async (file) => {
		if (!file) return;
		try {
			const raw = await file.text();
			const parsed = parseLedgerBackup(raw);
			const result = replaceAll(parsed);
			if (!result.ok) {
				toast.error(result.error);
				return;
			}
			toast.success("Данные восстановлены");
			onOpenChange(false);
		} catch {
			toast.error("Не удалось прочитать файл");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 pb-6 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Ещё" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Книга хранится на этом устройстве. Сделайте копию, если меняете телефон." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallBanner, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "outline",
							onClick: exportCsv,
							children: "Выгрузить таблицу CSV"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "outline",
							onClick: exportJson,
							children: "Сохранить копию JSON"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "outline",
							onClick: () => fileRef.current?.click(),
							children: "Восстановить из JSON"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json,.json",
							className: "hidden",
							onChange: (event) => {
								const file = event.target.files?.[0];
								onImport(file);
								event.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "outline",
							onClick: () => {
								loadDemo();
								onOpenChange(false);
								toast.success("Загружен пример");
							},
							children: "Загрузить пример"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "outline",
							onClick: () => {
								if (!days.length) return;
								if (window.confirm("Удалить все записи на этом устройстве?")) {
									clearAll();
									onOpenChange(false);
									toast.success("Книга очищена");
								}
							},
							children: "Очистить книгу"
						})
					]
				})
			]
		}) })
	});
}
//#endregion
export { MoreSheet };
