import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Plus, o as FileText, s as Ellipsis, t as TriangleAlert, u as BookOpen } from "../_libs/lucide-react.mjs";
import { l as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BOojmBmH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-[color,background-color,transform] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-paper disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-ink text-fg-on-ink hover:bg-ink/90",
			primary: "bg-pine text-pine-fg hover:bg-pine/90",
			outline: "border border-border bg-paper-raised text-fg hover:bg-cream",
			ghost: "text-fg hover:bg-cream",
			danger: "bg-brick text-fg-on-ink hover:bg-brick/90"
		},
		size: {
			default: "h-11 px-4 text-sm",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function sumExpenses(expenses) {
	return expenses.reduce((sum, item) => sum + item.amount, 0);
}
function computeLedger(days) {
	const sorted = [...days].sort((a, b) => a.date.localeCompare(b.date));
	let running = 0;
	return sorted.map((day) => {
		const expenseTotal = sumExpenses(day.expenses);
		const dayNet = day.revenue - expenseTotal;
		running += dayNet;
		return {
			...day,
			expenseTotal,
			dayNet,
			runningBalance: running
		};
	});
}
function emptyCategoryTotals() {
	return {
		supplies: 0,
		salary: 0,
		other: 0
	};
}
function reportForPeriod(days, from, to) {
	const start = from <= to ? from : to;
	const end = from <= to ? to : from;
	const computed = computeLedger(days);
	const before = computed.filter((day) => day.date < start);
	const inRange = computed.filter((day) => day.date >= start && day.date <= end);
	const opening = before.at(-1)?.runningBalance ?? 0;
	const revenue = inRange.reduce((sum, day) => sum + day.revenue, 0);
	const expenses = inRange.flatMap((day) => day.expenses.map((expense) => ({
		...expense,
		date: day.date
	})));
	const expenseSum = expenses.reduce((sum, item) => sum + item.amount, 0);
	const byCategory = emptyCategoryTotals();
	for (const expense of expenses) byCategory[expense.category] += expense.amount;
	return {
		from: start,
		to: end,
		opening,
		revenue,
		expenseSum,
		byCategory,
		expenses,
		net: revenue - expenseSum,
		closing: inRange.at(-1)?.runningBalance ?? opening,
		days: inRange
	};
}
function monthBounds(isoDate) {
	const [year, month] = isoDate.split("-").map(Number);
	const last = new Date(year, month, 0).getDate();
	const pad = (value) => String(value).padStart(2, "0");
	return {
		from: `${year}-${pad(month)}-01`,
		to: `${year}-${pad(month)}-${pad(last)}`
	};
}
function todayIso(now = /* @__PURE__ */ new Date()) {
	const pad = (value) => String(value).padStart(2, "0");
	return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}
var rubFormatter = new Intl.NumberFormat("ru-RU", {
	style: "currency",
	currency: "RUB",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
var signedRubFormatter = new Intl.NumberFormat("ru-RU", {
	style: "currency",
	currency: "RUB",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2,
	signDisplay: "exceptZero"
});
function formatMoney(kopecks) {
	return rubFormatter.format(kopecks / 100);
}
function formatMoneySigned(kopecks) {
	return signedRubFormatter.format(kopecks / 100).replace("+", "+");
}
function parseMoney(input) {
	const cleaned = input.trim().replace(/\s/g, "").replace(",", ".");
	if (cleaned === "") return 0;
	if (!/^\d+(\.\d{0,2})?$/.test(cleaned)) return null;
	const value = Number(cleaned);
	if (!Number.isFinite(value) || value < 0) return null;
	return Math.round(value * 100);
}
function moneyToInput(kopecks) {
	if (!kopecks) return "";
	const rub = kopecks / 100;
	return Number.isInteger(rub) ? String(rub) : rub.toFixed(2).replace(".", ",");
}
function newId() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function rub(value) {
	return Math.round(value * 100);
}
function expense(category, title, amount) {
	return {
		id: newId(),
		category,
		title,
		amount: rub(amount)
	};
}
function day(date, revenue, expenses, note = "") {
	return {
		id: newId(),
		date,
		revenue: rub(revenue),
		expenses,
		note
	};
}
function createDemoLedger() {
	return [
		day("2026-09-15", 48600, [
			expense("supplies", "Мука, масло, дрожжи", 12400),
			expense("other", "Аренда за сентябрь", 18e3),
			expense("other", "Коммунальные услуги", 4200)
		]),
		day("2026-09-16", 31250, [expense("supplies", "Молоко и яйца", 6800), expense("other", "Доставка сырья", 1500)]),
		day("2026-09-17", 35800, [expense("salary", "Аванс пекарю", 12e3), expense("supplies", "Упаковка и пакеты", 2100)]),
		day("2026-09-18", 27400, [expense("supplies", "Начинки и ягоды", 5400)]),
		day("2026-09-19", 52100, [expense("supplies", "Пятничная поставка", 9800), expense("other", "Ремонт витрины", 3500)]),
		day("2026-09-20", 61400, [expense("salary", "Выходные продавцам", 16e3), expense("supplies", "Кофе и чай", 4300)]),
		day("2026-09-22", 19800, [expense("other", "Налог УСН", 8500)]),
		day("2026-09-23", 33600, [expense("supplies", "Овощи и зелень", 4100), expense("other", "Хозтовары", 900)]),
		day("2026-09-25", 40250, [expense("salary", "Зарплата кассиру", 18e3), expense("supplies", "Молочная продукция", 7200)]),
		day("2026-09-27", 28900, [expense("supplies", "Хлебные смеси", 3600)]),
		day("2026-09-29", 45700, [expense("other", "Реклама в соцсетях", 2500), expense("supplies", "Шоколад и орехи", 6100)]),
		day("2026-09-30", 53800, [expense("salary", "Расчёт за сентябрь", 22e3), expense("other", "Связь и эквайринг", 1800)]),
		day("2026-10-01", 36400, [expense("supplies", "Октябрьская поставка", 11200), expense("other", "Аренда за октябрь", 18e3)]),
		day("2026-10-02", 41200, [expense("supplies", "Фрукты к выпечке", 4700), expense("other", "Бензин", 2200)]),
		day("2026-10-03", 29750, [expense("salary", "Подработка грузчика", 4500)], "Короткий день, утренние заказы")
	];
}
var EXPENSE_CATEGORIES = [
	"supplies",
	"salary",
	"other"
];
var CATEGORY_LABEL = {
	supplies: "Поставки",
	salary: "Зарплата",
	other: "Прочее"
};
var STORAGE_KEY = "kassa-ledger-v1";
function dateTaken(days, date, exceptId) {
	return days.some((day) => day.date === date && day.id !== exceptId);
}
var useLedgerStore = create()(persist((set, get) => ({
	days: [],
	demo: false,
	formOpen: false,
	editingId: null,
	draftDate: null,
	openCreate: (date) => set({
		formOpen: true,
		editingId: null,
		draftDate: date ?? null
	}),
	openEdit: (id) => set({
		formOpen: true,
		editingId: id,
		draftDate: null
	}),
	closeForm: () => set({
		formOpen: false,
		editingId: null,
		draftDate: null
	}),
	upsertDay: (input, id) => {
		const date = input.date;
		if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return {
			ok: false,
			error: "Укажите корректную дату."
		};
		if (input.revenue < 0) return {
			ok: false,
			error: "Выручка не может быть отрицательной."
		};
		if (input.expenses.some((item) => item.amount < 0 || !item.title.trim())) return {
			ok: false,
			error: "У каждого расхода должно быть название и сумма."
		};
		const { days } = get();
		if (dateTaken(days, date, id)) return {
			ok: false,
			error: "На эту дату запись уже есть. Откройте её для правки."
		};
		if (id) {
			set({
				days: days.map((day) => day.id === id ? {
					...day,
					...input,
					id
				} : day),
				demo: false,
				formOpen: false,
				editingId: null,
				draftDate: null
			});
			return {
				ok: true,
				id
			};
		}
		const nextId = crypto.randomUUID();
		set({
			days: [...days, {
				...input,
				id: nextId
			}],
			demo: false,
			formOpen: false,
			editingId: null,
			draftDate: null
		});
		return {
			ok: true,
			id: nextId
		};
	},
	removeDay: (id) => set((state) => ({
		days: state.days.filter((day) => day.id !== id),
		demo: false,
		formOpen: false,
		editingId: null
	})),
	loadDemo: () => set({
		days: createDemoLedger(),
		demo: true,
		formOpen: false,
		editingId: null
	}),
	clearAll: () => set({
		days: [],
		demo: false,
		formOpen: false,
		editingId: null
	}),
	replaceAll: (days) => {
		if (!Array.isArray(days) || days.some((day) => !day?.date || typeof day.revenue !== "number")) return {
			ok: false,
			error: "Файл не похож на кассовую книгу."
		};
		set({
			days,
			demo: false
		});
		return {
			ok: true,
			id: "import"
		};
	}
}), {
	name: STORAGE_KEY,
	skipHydration: true,
	partialize: (state) => ({
		days: state.days,
		demo: state.demo
	})
}));
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var SEEN_KEY = "kassa-ledger-seen";
function restoreFromStorage() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed.state?.days)) {
				useLedgerStore.setState({
					days: parsed.state.days,
					demo: Boolean(parsed.state.demo)
				});
				return;
			}
		}
		if (!localStorage.getItem(SEEN_KEY)) useLedgerStore.getState().loadDemo();
	} catch {} finally {
		localStorage.setItem(SEEN_KEY, "1");
	}
}
function LedgerHydration({ children }) {
	(0, import_react.useLayoutEffect)(() => {
		restoreFromStorage();
		useLedgerStore.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-app-ready": "true",
		children
	});
}
var DayFormSheet = (0, import_react.lazy)(() => import("./day-form-CU400XrM.mjs").then((module) => ({ default: module.DayFormSheet })));
var MoreSheet = (0, import_react.lazy)(() => import("./more-sheet-I4u23OR0.mjs").then((module) => ({ default: module.MoreSheet })));
function AppShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerHydration, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellFrame, { children }) });
}
function ShellFrame({ children }) {
	const days = useLedgerStore((s) => s.days);
	const formOpen = useLedgerStore((s) => s.formOpen);
	const openCreate = useLedgerStore((s) => s.openCreate);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const balance = (0, import_react.useMemo)(() => computeLedger(days).at(-1)?.runningBalance ?? 0, [days]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-paper text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "relative z-10 bg-ink text-fg-on-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-start justify-between gap-3 px-4 pb-5 pt-[max(1rem,env(safe-area-inset-top))]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.22em] text-cream/70",
							children: "Учёт доходов"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-[1.75rem] leading-tight tracking-tight",
							children: "Кассовая книга"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs uppercase tracking-[0.18em] text-cream/70",
							children: "Нарастающий баланс"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-1 font-display text-4xl tabular-nums tracking-tight", balance < 0 && "text-brick-soft"),
							children: formatMoney(balance)
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "text-fg-on-ink hover:bg-cream/10 hover:text-fg-on-ink",
							"aria-label": "Ещё",
							onClick: () => setMoreOpen(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "primary",
							"aria-label": "Добавить день",
							onClick: () => openCreate(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-5xl px-4 py-5 pb-28",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-print fixed inset-x-0 bottom-0 z-20 border-t border-border bg-paper-raised pb-[env(safe-area-inset-bottom)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-5xl grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						to: "/",
						active: pathname === "/",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5" }),
						label: "Книга"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						to: "/report",
						active: pathname === "/report",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" }),
						label: "Справка"
					})]
				})
			}),
			formOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: null,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayFormSheet, {})
			}) : null,
			moreOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: null,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreSheet, {
					open: moreOpen,
					onOpenChange: setMoreOpen
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				richColors: false
			})
		]
	});
}
function NavLink({ to, active, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-xs", active ? "text-pine" : "text-fg-muted"),
		children: [icon, label]
	});
}
var styles_default = "/assets/styles-ChMLOcSp.css";
var APP_NAME = "Кассовая книга";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Учёт выручки и расходов с нарастающим балансом и справкой за период."
			},
			{
				name: "theme-color",
				content: "#1a1814"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-title",
				content: APP_NAME
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/icon-192.png"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "font-sans",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$1 = () => import("./routes-B31ARg7d.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./report-BPoYdEwb.mjs");
var Route = createFileRoute("/report")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	ReportRoute: Route.update({
		id: "/report",
		path: "/report",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { formatMoney as a, newId as c, monthBounds as d, reportForPeriod as f, cn as h, EXPENSE_CATEGORIES as i, parseMoney as l, Button as m, useLedgerStore as n, formatMoneySigned as o, todayIso as p, CATEGORY_LABEL as r, moneyToInput as s, router_exports as t, computeLedger as u };
