import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Download, r as Printer } from "../_libs/lucide-react.mjs";
import { a as formatMoney, d as monthBounds, f as reportForPeriod, h as cn, m as Button, n as useLedgerStore, o as formatMoneySigned, p as todayIso, r as CATEGORY_LABEL } from "./router-BOojmBmH.mjs";
import { n as Label, t as Input } from "./label-aAQWW89d.mjs";
import { n as ledgerToCsv, t as downloadText } from "./export-D-U4n4fA.mjs";
import { r as formatPeriodRange, t as formatDayShort } from "./format-DuF5PP0y.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/report-BPoYdEwb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function quarterBounds(iso) {
	const [year, month] = iso.split("-").map(Number);
	const startMonth = Math.floor((month - 1) / 3) * 3 + 1;
	const endMonth = startMonth + 2;
	const pad = (value) => String(value).padStart(2, "0");
	const last = new Date(year, endMonth, 0).getDate();
	return {
		from: `${year}-${pad(startMonth)}-01`,
		to: `${year}-${pad(endMonth)}-${pad(last)}`
	};
}
function allBounds(dates, fallback) {
	if (dates.length === 0) return {
		from: fallback,
		to: fallback
	};
	return {
		from: dates[0],
		to: dates[dates.length - 1]
	};
}
function ReportView() {
	const days = useLedgerStore((s) => s.days);
	const today = todayIso();
	const [preset, setPreset] = (0, import_react.useState)("month");
	const [customFrom, setCustomFrom] = (0, import_react.useState)(monthBounds(today).from);
	const [customTo, setCustomTo] = (0, import_react.useState)(today);
	const [chartReady, setChartReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setChartReady(true);
	}, []);
	const sortedDates = (0, import_react.useMemo)(() => [...days].map((day) => day.date).sort(), [days]);
	const range = (0, import_react.useMemo)(() => {
		if (preset === "month") return monthBounds(today);
		if (preset === "quarter") return quarterBounds(today);
		if (preset === "all") return allBounds(sortedDates, today);
		return {
			from: customFrom || today,
			to: customTo || today
		};
	}, [
		preset,
		today,
		sortedDates,
		customFrom,
		customTo
	]);
	const report = (0, import_react.useMemo)(() => reportForPeriod(days, range.from, range.to), [
		days,
		range.from,
		range.to
	]);
	const chart = (0, import_react.useMemo)(() => {
		return [{
			label: "начало",
			balance: report.opening / 100
		}, ...report.days.map((day) => ({
			label: formatDayShort(day.date),
			balance: day.runningBalance / 100
		}))];
	}, [report]);
	const categories = Object.keys(CATEGORY_LABEL).map((key) => ({
		key,
		label: CATEGORY_LABEL[key],
		amount: report.byCategory[key]
	}));
	const onPrint = () => window.print();
	const onCsv = () => {
		downloadText(`spravka-${report.from}-${report.to}.csv`, ledgerToCsv(report.days), "text/csv;charset=utf-8");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print flex flex-wrap gap-2",
				children: [
					["month", "Этот месяц"],
					["quarter", "Квартал"],
					["all", "Вся книга"],
					["custom", "Период"]
				].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPreset(key),
					className: cn("h-9 rounded-full px-3 text-sm", preset === key ? "bg-ink text-fg-on-ink" : "bg-cream text-fg-muted"),
					children: label
				}, key))
			}),
			preset === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "from",
						children: "С даты"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "from",
						type: "date",
						value: customFrom,
						onChange: (event) => setCustomFrom(event.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "to",
						children: "По дату"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "to",
						type: "date",
						value: customTo,
						onChange: (event) => setCustomTo(event.target.value)
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "print-sheet rounded-xl border border-border bg-paper-raised p-4 md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "border-b border-border pb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.18em] text-fg-subtle",
								children: "Итоговая справка"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-2xl font-medium tracking-tight",
								children: "Движение денежных средств"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-fg-muted",
								children: formatPeriodRange(report.from, report.to)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Остаток на начало периода",
								value: formatMoney(report.opening)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Выручка",
								value: formatMoney(report.revenue),
								tone: "pine"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Расходы",
								value: formatMoney(report.expenseSum),
								tone: "brick"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-cream/70 px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-wide text-fg-subtle",
									children: "В том числе"
								}), categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: item.label,
									value: formatMoney(item.amount),
									muted: true
								}, item.key))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Результат периода",
								value: formatMoneySigned(report.net),
								strong: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Остаток на конец периода",
								value: formatMoney(report.closing),
								strong: true
							})
						]
					}),
					report.days.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Нарастающий баланс"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-52 w-full",
							children: chartReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
									data: chart,
									margin: {
										top: 8,
										right: 8,
										left: 0,
										bottom: 0
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-border)",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "label",
											tick: {
												fill: "var(--color-fg-muted)",
												fontSize: 11
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											width: 64,
											tick: {
												fill: "var(--color-fg-muted)",
												fontSize: 11
											},
											tickFormatter: (value) => new Intl.NumberFormat("ru-RU", { notation: "compact" }).format(value)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											formatter: (value) => [formatMoney(Math.round(Number(value) * 100)), "Баланс"],
											contentStyle: {
												background: "var(--color-paper-raised)",
												border: "1px solid var(--color-border)",
												borderRadius: 8
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "balance",
											stroke: "var(--color-pine)",
											fill: "var(--color-pine-soft)",
											strokeWidth: 2
										})
									]
								})
							}) : null
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-fg-muted",
						children: "За выбранный период записей нет."
					}),
					report.expenses.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Расходы с назначением"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 divide-y divide-border",
							children: report.expenses.map((expense) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start justify-between gap-3 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "break-words",
										children: expense.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-fg-subtle",
										children: [
											formatDayShort(expense.date),
											" · ",
											CATEGORY_LABEL[expense.category]
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 tabular-nums text-brick",
									children: formatMoney(expense.amount)
								})]
							}, expense.id))
						})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "primary",
					onClick: onPrint,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Печать справки"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: onCsv,
					disabled: report.days.length === 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Скачать CSV"]
				})]
			})
		]
	});
}
function Row({ label, value, tone, strong, muted }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-4 py-0.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: cn("text-fg-muted", muted && "text-sm"),
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("tabular-nums", strong && "font-semibold", tone === "pine" && "text-pine", tone === "brick" && "text-brick"),
			children: value
		})]
	});
}
function ReportPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportView, {});
}
//#endregion
export { ReportPage as component };
