import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Pencil, i as Plus, l as ChevronDown } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as formatMoney, d as monthBounds, h as cn, m as Button, n as useLedgerStore, o as formatMoneySigned, p as todayIso, r as CATEGORY_LABEL, u as computeLedger } from "./router-BOojmBmH.mjs";
import { t as InstallBanner } from "./install-banner-CWj_VQZm.mjs";
import { i as formatWeekday, n as formatDayTitle, t as formatDayShort } from "./format-DuF5PP0y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B31ARg7d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		cream: "bg-cream text-fg",
		pine: "bg-pine-soft text-pine",
		brick: "bg-brick-soft text-brick",
		ink: "bg-ink/8 text-fg"
	} },
	defaultVariants: { variant: "cream" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function Journal() {
	const days = useLedgerStore((s) => s.days);
	const demo = useLedgerStore((s) => s.demo);
	const openCreate = useLedgerStore((s) => s.openCreate);
	const openEdit = useLedgerStore((s) => s.openEdit);
	const loadDemo = useLedgerStore((s) => s.loadDemo);
	const clearAll = useLedgerStore((s) => s.clearAll);
	const computed = (0, import_react.useMemo)(() => computeLedger(days), [days]);
	const months = (0, import_react.useMemo)(() => {
		const keys = new Set(computed.map((day) => day.date.slice(0, 7)));
		keys.add(todayIso().slice(0, 7));
		return [...keys].sort().reverse();
	}, [computed]);
	const [month, setMonth] = (0, import_react.useState)("all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const visible = (0, import_react.useMemo)(() => {
		return [...month === "all" ? computed : computed.filter((day) => day.date.startsWith(month))].reverse();
	}, [computed, month]);
	const monthStats = (0, import_react.useMemo)(() => {
		if (month === "all") return {
			revenue: computed.reduce((sum, day) => sum + day.revenue, 0),
			expenses: computed.reduce((sum, day) => sum + day.expenseTotal, 0)
		};
		const bounds = monthBounds(`${month}-01`);
		const slice = computed.filter((day) => day.date >= bounds.from && day.date <= bounds.to);
		return {
			revenue: slice.reduce((sum, day) => sum + day.revenue, 0),
			expenses: slice.reduce((sum, day) => sum + day.expenseTotal, 0)
		};
	}, [computed, month]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			demo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3 rounded-lg bg-cream px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: "Показан пример за сентябрь–октябрь. Можно править или начать с чистого листа."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: clearAll,
					children: "Очистить"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Выручка",
					value: formatMoney(monthStats.revenue),
					tone: "pine"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Расходы",
					value: formatMoney(monthStats.expenses),
					tone: "brick"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: month === "all",
					onClick: () => setMonth("all"),
					children: "Все дни"
				}), months.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: month === key,
					onClick: () => setMonth(key),
					children: monthLabel(key)
				}, key))]
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				onCreate: () => openCreate(),
				onDemo: loadDemo
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-hidden rounded-xl border border-border bg-paper-raised md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-cream/80 text-left text-fg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Дата"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right font-medium",
								children: "Выручка"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Расходы"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right font-medium",
								children: "Баланс"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "cursor-pointer border-t border-border align-top hover:bg-cream/40",
						onClick: () => openEdit(day.id),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: formatDayTitle(day.date)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs uppercase text-fg-subtle",
									children: formatWeekday(day.date)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-right tabular-nums text-pine",
								children: formatMoney(day.revenue)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-right tabular-nums text-brick md:text-left",
									children: formatMoney(day.expenseTotal)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-1 space-y-0.5 text-xs text-fg-muted",
									children: day.expenses.map((expense) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											CATEGORY_LABEL[expense.category],
											" · ",
											expense.title
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: formatMoney(expense.amount)
										})]
									}, expense.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: cn("px-4 py-3 text-right font-medium tabular-nums", day.runningBalance < 0 ? "text-brick" : "text-fg"),
								children: formatMoney(day.runningBalance)
							})
						]
					}, day.id)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2 md:hidden",
				children: visible.map((day) => {
					const expanded = openId === day.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-border bg-paper-raised p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-start gap-3 text-left",
							onClick: () => setOpenId(expanded ? null : day.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: formatDayShort(day.date)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs uppercase text-fg-subtle",
										children: formatWeekday(day.date)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-fg-subtle",
											children: "Выручка"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular-nums text-pine",
											children: formatMoney(day.revenue)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-fg-subtle",
											children: "Расходы"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular-nums text-brick",
											children: formatMoney(day.expenseTotal)
										})]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] uppercase tracking-wide text-fg-subtle",
										children: "Баланс"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: cn("tabular-nums text-sm font-semibold", day.runningBalance < 0 ? "text-brick" : "text-fg"),
										children: formatMoney(day.runningBalance)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("ml-auto mt-1 size-4 text-fg-subtle transition-transform duration-150", expanded && "rotate-180") })
								]
							})]
						}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 border-t border-border pt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-fg-subtle",
									children: [
										"Итог дня ",
										formatMoneySigned(day.dayNet),
										" · нарастающий с учётом прошлых дней"
									]
								}),
								day.expenses.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 space-y-1.5",
									children: day.expenses.map((expense) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start justify-between gap-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: expense.category === "salary" ? "ink" : expense.category === "supplies" ? "pine" : "cream",
											children: CATEGORY_LABEL[expense.category]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-fg",
											children: expense.title
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 tabular-nums",
											children: formatMoney(expense.amount)
										})]
									}, expense.id))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-fg-muted",
									children: "Расходов нет"
								}),
								day.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-fg-muted",
									children: day.note
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "mt-3 w-full",
									variant: "outline",
									onClick: () => openEdit(day.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), "Править день"]
								})
							]
						}) : null]
					}, day.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "w-full md:w-auto",
				variant: "primary",
				onClick: () => openCreate(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Добавить день"]
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-paper-raised px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-wide text-fg-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1 text-lg font-semibold tabular-nums", tone === "pine" ? "text-pine" : "text-brick"),
			children: value
		})]
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 shrink-0 rounded-full px-3 text-sm", active ? "bg-ink text-fg-on-ink" : "bg-cream text-fg-muted"),
		children
	});
}
function monthLabel(key) {
	const [year, month] = key.split("-").map(Number);
	return new Date(year, month - 1, 1).toLocaleDateString("ru-RU", {
		month: "long",
		year: "numeric"
	});
}
function EmptyState({ onCreate, onDemo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-dashed border-border bg-paper-raised px-5 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Книга пуста"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-sm text-fg-muted",
				children: "Добавьте первый день: дату, выручку и расходы. Баланс будет копиться с каждым следующим днём."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col items-center gap-2 sm:flex-row sm:justify-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "primary",
					onClick: onCreate,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Первый день"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onDemo,
					children: "Показать пример"
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Journal, {});
}
//#endregion
export { Home as component };
