import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { h as cn } from "./router-BOojmBmH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/label-aAQWW89d.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, type = "text", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-border bg-paper-raised px-3 text-base text-fg shadow-none transition-colors duration-150", "placeholder:text-fg-subtle file:border-0 file:bg-transparent file:text-sm file:font-medium", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium text-fg-muted", className),
		...props
	});
}
//#endregion
export { Label as n, Input as t };
