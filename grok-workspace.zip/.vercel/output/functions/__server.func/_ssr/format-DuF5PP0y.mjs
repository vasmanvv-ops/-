//#region node_modules/.nitro/vite/services/ssr/assets/format-DuF5PP0y.js
function parseDay(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	return new Date(year, month - 1, day);
}
function formatDayTitle(iso) {
	return new Intl.DateTimeFormat("ru-RU", {
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(parseDay(iso));
}
function formatDayShort(iso) {
	return new Intl.DateTimeFormat("ru-RU", {
		day: "numeric",
		month: "short"
	}).format(parseDay(iso));
}
function formatWeekday(iso) {
	return new Intl.DateTimeFormat("ru-RU", { weekday: "short" }).format(parseDay(iso));
}
function formatPeriodRange(from, to) {
	return `${formatDayTitle(from)} — ${formatDayTitle(to)}`;
}
//#endregion
export { formatWeekday as i, formatDayTitle as n, formatPeriodRange as r, formatDayShort as t };
