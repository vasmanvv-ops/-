//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CtVGzYzJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/report"],
		preloads: ["/assets/index-B7q_viOf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B7q_viOf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B-77TQtx.js",
			"/assets/install-banner-JxQ2h7YE.js",
			"/assets/format-DxfPVOmH.js"
		]
	},
	"/report": {
		filePath: "/workspace/src/routes/report.tsx",
		children: void 0,
		preloads: [
			"/assets/report-BGzSV56C.js",
			"/assets/download-CPoZaq-E.js",
			"/assets/label-DPFdcC4U.js",
			"/assets/export-BXTS6SXe.js",
			"/assets/format-DxfPVOmH.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
