import { useRef } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  downloadText,
  ledgerToCsv,
  parseLedgerBackup,
  serializeLedger,
} from "@/lib/ledger/export";
import { useLedgerStore } from "@/lib/ledger/store";
import { InstallBanner } from "./install-banner";

export function MoreSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const days = useLedgerStore((s) => s.days);
  const loadDemo = useLedgerStore((s) => s.loadDemo);
  const clearAll = useLedgerStore((s) => s.clearAll);
  const replaceAll = useLedgerStore((s) => s.replaceAll);
  const fileRef = useRef<HTMLInputElement>(null);

  const exportJson = () => {
    downloadText(
      "kassovaya-kniga.json",
      serializeLedger(days),
      "application/json",
    );
    toast.success("Файл книги сохранён");
  };

  const exportCsv = () => {
    downloadText("kassovaya-kniga.csv", ledgerToCsv(days), "text/csv;charset=utf-8");
    toast.success("Таблица выгружена");
  };

  const onImport = async (file: File | undefined) => {
    if (!file) return;
    try {
      const raw = await file.text();
      const parsed = parseLedgerBackup(raw);
      const result = replaceAll(parsed);
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      toast.success("Данные восстановлены");
      onOpenChange(false);
    } catch {
      toast.error("Не удалось прочитать файл");
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent>
        <div className="px-5 pb-6 pt-4">
          <SheetTitle>Ещё</SheetTitle>
          <SheetDescription>
            Книга хранится на этом устройстве. Сделайте копию, если меняете телефон.
          </SheetDescription>
          <div className="mt-4 space-y-3">
            <InstallBanner />
            <Button className="w-full" variant="outline" onClick={exportCsv}>
              Выгрузить таблицу CSV
            </Button>
            <Button className="w-full" variant="outline" onClick={exportJson}>
              Сохранить копию JSON
            </Button>
            <Button className="w-full" variant="outline" onClick={() => fileRef.current?.click()}>
              Восстановить из JSON
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0];
                void onImport(file);
                event.target.value = "";
              }}
            />
            <Button
              className="w-full"
              variant="outline"
              onClick={() => {
                loadDemo();
                onOpenChange(false);
                toast.success("Загружен пример");
              }}
            >
              Загрузить пример
            </Button>
            <Button
              className="w-full"
              variant="outline"
              onClick={() => {
                if (!days.length) return;
                if (window.confirm("Удалить все записи на этом устройстве?")) {
                  clearAll();
                  onOpenChange(false);
                  toast.success("Книга очищена");
                }
              }}
            >
              Очистить книгу
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
