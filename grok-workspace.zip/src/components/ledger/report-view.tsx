import { useEffect, useMemo, useState } from "react";
import { Download, Printer } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { monthBounds, reportForPeriod, todayIso } from "@/lib/ledger/calc";
import { downloadText, ledgerToCsv } from "@/lib/ledger/export";
import { formatDayShort, formatPeriodRange } from "@/lib/ledger/format";
import { formatMoney, formatMoneySigned } from "@/lib/ledger/money";
import { useLedgerStore } from "@/lib/ledger/store";
import { CATEGORY_LABEL, type ExpenseCategory } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

type Preset = "month" | "quarter" | "all" | "custom";

function quarterBounds(iso: string) {
  const [year, month] = iso.split("-").map(Number);
  const q = Math.floor((month - 1) / 3);
  const startMonth = q * 3 + 1;
  const endMonth = startMonth + 2;
  const pad = (value: number) => String(value).padStart(2, "0");
  const last = new Date(year, endMonth, 0).getDate();
  return {
    from: `${year}-${pad(startMonth)}-01`,
    to: `${year}-${pad(endMonth)}-${pad(last)}`,
  };
}

function allBounds(dates: string[], fallback: string) {
  if (dates.length === 0) return { from: fallback, to: fallback };
  return { from: dates[0], to: dates[dates.length - 1] };
}

export function ReportView() {
  const days = useLedgerStore((s) => s.days);
  const today = todayIso();
  const [preset, setPreset] = useState<Preset>("month");
  const [customFrom, setCustomFrom] = useState(monthBounds(today).from);
  const [customTo, setCustomTo] = useState(today);
  const [chartReady, setChartReady] = useState(false);

  useEffect(() => {
    setChartReady(true);
  }, []);

  const sortedDates = useMemo(
    () => [...days].map((day) => day.date).sort(),
    [days],
  );

  const range = useMemo(() => {
    if (preset === "month") return monthBounds(today);
    if (preset === "quarter") return quarterBounds(today);
    if (preset === "all") return allBounds(sortedDates, today);
    return { from: customFrom || today, to: customTo || today };
  }, [preset, today, sortedDates, customFrom, customTo]);

  const report = useMemo(
    () => reportForPeriod(days, range.from, range.to),
    [days, range.from, range.to],
  );

  const chart = useMemo(() => {
    return [
      { label: "начало", balance: report.opening / 100 },
      ...report.days.map((day) => ({
        label: formatDayShort(day.date),
        balance: day.runningBalance / 100,
      })),
    ];
  }, [report]);

  const categories = (Object.keys(CATEGORY_LABEL) as ExpenseCategory[]).map((key) => ({
    key,
    label: CATEGORY_LABEL[key],
    amount: report.byCategory[key],
  }));

  const onPrint = () => window.print();
  const onCsv = () => {
    downloadText(
      `spravka-${report.from}-${report.to}.csv`,
      ledgerToCsv(report.days),
      "text/csv;charset=utf-8",
    );
  };

  return (
    <div className="space-y-5">
      <div className="no-print flex flex-wrap gap-2">
        {(
          [
            ["month", "Этот месяц"],
            ["quarter", "Квартал"],
            ["all", "Вся книга"],
            ["custom", "Период"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setPreset(key)}
            className={cn(
              "h-9 rounded-full px-3 text-sm",
              preset === key ? "bg-ink text-fg-on-ink" : "bg-cream text-fg-muted",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {preset === "custom" ? (
        <div className="no-print grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="from">С даты</Label>
            <Input
              id="from"
              type="date"
              value={customFrom}
              onChange={(event) => setCustomFrom(event.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="to">По дату</Label>
            <Input
              id="to"
              type="date"
              value={customTo}
              onChange={(event) => setCustomTo(event.target.value)}
            />
          </div>
        </div>
      ) : null}

      <article className="print-sheet rounded-xl border border-border bg-paper-raised p-4 md:p-6">
        <header className="border-b border-border pb-4">
          <p className="text-xs uppercase tracking-[0.18em] text-fg-subtle">Итоговая справка</p>
          <h2 className="mt-1 font-display text-2xl font-medium tracking-tight">
            Движение денежных средств
          </h2>
          <p className="mt-1 text-sm text-fg-muted">{formatPeriodRange(report.from, report.to)}</p>
        </header>

        <dl className="mt-4 space-y-2 text-sm">
          <Row label="Остаток на начало периода" value={formatMoney(report.opening)} />
          <Row label="Выручка" value={formatMoney(report.revenue)} tone="pine" />
          <Row label="Расходы" value={formatMoney(report.expenseSum)} tone="brick" />
          <div className="rounded-lg bg-cream/70 px-3 py-2">
            <p className="text-xs uppercase tracking-wide text-fg-subtle">В том числе</p>
            {categories.map((item) => (
              <Row
                key={item.key}
                label={item.label}
                value={formatMoney(item.amount)}
                muted
              />
            ))}
          </div>
          <Row label="Результат периода" value={formatMoneySigned(report.net)} strong />
          <Row
            label="Остаток на конец периода"
            value={formatMoney(report.closing)}
            strong
          />
        </dl>

        {report.days.length > 0 ? (
          <div className="mt-6">
            <h3 className="text-sm font-medium">Нарастающий баланс</h3>
            <div className="mt-2 h-52 w-full">
              {chartReady ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chart} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke="var(--color-border)" vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: "var(--color-fg-muted)", fontSize: 11 }} />
                    <YAxis
                      width={64}
                      tick={{ fill: "var(--color-fg-muted)", fontSize: 11 }}
                      tickFormatter={(value: number) =>
                        new Intl.NumberFormat("ru-RU", { notation: "compact" }).format(value)
                      }
                    />
                    <Tooltip
                      formatter={(value) => [
                        formatMoney(Math.round(Number(value) * 100)),
                        "Баланс",
                      ]}
                      contentStyle={{
                        background: "var(--color-paper-raised)",
                        border: "1px solid var(--color-border)",
                        borderRadius: 8,
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="balance"
                      stroke="var(--color-pine)"
                      fill="var(--color-pine-soft)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : null}
            </div>
          </div>
        ) : (
          <p className="mt-4 text-sm text-fg-muted">За выбранный период записей нет.</p>
        )}

        {report.expenses.length > 0 ? (
          <div className="mt-6">
            <h3 className="text-sm font-medium">Расходы с назначением</h3>
            <ul className="mt-2 divide-y divide-border">
              {report.expenses.map((expense) => (
                <li key={expense.id} className="flex items-start justify-between gap-3 py-2 text-sm">
                  <div className="min-w-0">
                    <p className="break-words">{expense.title}</p>
                    <p className="text-xs text-fg-subtle">
                      {formatDayShort(expense.date)} · {CATEGORY_LABEL[expense.category]}
                    </p>
                  </div>
                  <span className="shrink-0 tabular-nums text-brick">{formatMoney(expense.amount)}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </article>

      <div className="no-print flex flex-col gap-2 sm:flex-row">
        <Button variant="primary" onClick={onPrint}>
          <Printer />
          Печать справки
        </Button>
        <Button
          variant="outline"
          onClick={onCsv}
          disabled={report.days.length === 0}
        >
          <Download />
          Скачать CSV
        </Button>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  tone,
  strong,
  muted,
}: {
  label: string;
  value: string;
  tone?: "pine" | "brick";
  strong?: boolean;
  muted?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-0.5">
      <dt className={cn("text-fg-muted", muted && "text-sm")}>{label}</dt>
      <dd
        className={cn(
          "tabular-nums",
          strong && "font-semibold",
          tone === "pine" && "text-pine",
          tone === "brick" && "text-brick",
        )}
      >
        {value}
      </dd>
    </div>
  );
}
