import { lazy, Suspense, useMemo, useState, type ReactNode } from "react";
import { BookOpen, FileText, MoreHorizontal, Plus } from "lucide-react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { computeLedger } from "@/lib/ledger/calc";
import { formatMoney } from "@/lib/ledger/money";
import { useLedgerStore } from "@/lib/ledger/store";
import { cn } from "@/lib/utils";
import { LedgerHydration } from "./hydrate";

const DayFormSheet = lazy(() =>
  import("./day-form").then((module) => ({ default: module.DayFormSheet })),
);
const MoreSheet = lazy(() =>
  import("./more-sheet").then((module) => ({ default: module.MoreSheet })),
);

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <LedgerHydration>
      <ShellFrame>{children}</ShellFrame>
    </LedgerHydration>
  );
}

function ShellFrame({ children }: { children: ReactNode }) {
  const days = useLedgerStore((s) => s.days);
  const formOpen = useLedgerStore((s) => s.formOpen);
  const openCreate = useLedgerStore((s) => s.openCreate);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [moreOpen, setMoreOpen] = useState(false);
  const balance = useMemo(
    () => computeLedger(days).at(-1)?.runningBalance ?? 0,
    [days],
  );

  return (
    <div className="min-h-dvh bg-paper text-fg">
      <header className="relative z-10 bg-ink text-fg-on-ink">
        <div className="mx-auto flex max-w-5xl items-start justify-between gap-3 px-4 pb-5 pt-[max(1rem,env(safe-area-inset-top))]">
          <div>
            <p className="text-xs uppercase tracking-[0.22em] text-cream/70">Учёт доходов</p>
            <h1 className="font-display text-[1.75rem] leading-tight tracking-tight">Кассовая книга</h1>
            <p className="mt-4 text-xs uppercase tracking-[0.18em] text-cream/70">
              Нарастающий баланс
            </p>
            <p
              className={cn(
                "mt-1 font-display text-4xl tabular-nums tracking-tight",
                balance < 0 && "text-brick-soft",
              )}
            >
              {formatMoney(balance)}
            </p>
          </div>
          <div className="flex shrink-0 gap-2">
            <Button
              size="icon"
              variant="ghost"
              className="text-fg-on-ink hover:bg-cream/10 hover:text-fg-on-ink"
              aria-label="Ещё"
              onClick={() => setMoreOpen(true)}
            >
              <MoreHorizontal />
            </Button>
            <Button
              size="icon"
              variant="primary"
              aria-label="Добавить день"
              onClick={() => openCreate()}
            >
              <Plus />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-5 pb-28">{children}</main>

      <nav className="no-print fixed inset-x-0 bottom-0 z-20 border-t border-border bg-paper-raised pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto grid max-w-5xl grid-cols-2">
          <NavLink to="/" active={pathname === "/"} icon={<BookOpen className="size-5" />} label="Книга" />
          <NavLink
            to="/report"
            active={pathname === "/report"}
            icon={<FileText className="size-5" />}
            label="Справка"
          />
        </div>
      </nav>

      {formOpen ? (
        <Suspense fallback={null}>
          <DayFormSheet />
        </Suspense>
      ) : null}
      {moreOpen ? (
        <Suspense fallback={null}>
          <MoreSheet open={moreOpen} onOpenChange={setMoreOpen} />
        </Suspense>
      ) : null}
      <Toaster position="top-center" richColors={false} />
    </div>
  );
}

function NavLink({
  to,
  active,
  icon,
  label,
}: {
  to: string;
  active: boolean;
  icon: ReactNode;
  label: string;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "flex h-14 flex-col items-center justify-center gap-0.5 text-xs",
        active ? "text-pine" : "text-fg-muted",
      )}
    >
      {icon}
      {label}
    </Link>
  );
}
