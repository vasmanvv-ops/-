import { useMemo, useState } from "react";
import { ChevronDown, Pencil, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { computeLedger, monthBounds, todayIso } from "@/lib/ledger/calc";
import { formatDayShort, formatDayTitle, formatWeekday } from "@/lib/ledger/format";
import { formatMoney, formatMoneySigned } from "@/lib/ledger/money";
import { useLedgerStore } from "@/lib/ledger/store";
import { CATEGORY_LABEL } from "@/lib/ledger/types";
import { cn } from "@/lib/utils";
import { InstallBanner } from "./install-banner";

export function Journal() {
  const days = useLedgerStore((s) => s.days);
  const demo = useLedgerStore((s) => s.demo);
  const openCreate = useLedgerStore((s) => s.openCreate);
  const openEdit = useLedgerStore((s) => s.openEdit);
  const loadDemo = useLedgerStore((s) => s.loadDemo);
  const clearAll = useLedgerStore((s) => s.clearAll);

  const computed = useMemo(() => computeLedger(days), [days]);
  const months = useMemo(() => {
    const keys = new Set(computed.map((day) => day.date.slice(0, 7)));
    keys.add(todayIso().slice(0, 7));
    return [...keys].sort().reverse();
  }, [computed]);

  const [month, setMonth] = useState("all");
  const [openId, setOpenId] = useState<string | null>(null);

  const visible = useMemo(() => {
    const list = month === "all" ? computed : computed.filter((day) => day.date.startsWith(month));
    return [...list].reverse();
  }, [computed, month]);

  const monthStats = useMemo(() => {
    if (month === "all") {
      return {
        revenue: computed.reduce((sum, day) => sum + day.revenue, 0),
        expenses: computed.reduce((sum, day) => sum + day.expenseTotal, 0),
      };
    }
    const bounds = monthBounds(`${month}-01`);
    const slice = computed.filter((day) => day.date >= bounds.from && day.date <= bounds.to);
    return {
      revenue: slice.reduce((sum, day) => sum + day.revenue, 0),
      expenses: slice.reduce((sum, day) => sum + day.expenseTotal, 0),
    };
  }, [computed, month]);

  return (
    <div className="space-y-4">
      {demo ? (
        <div className="flex items-start justify-between gap-3 rounded-lg bg-cream px-3 py-3">
          <p className="text-sm text-fg">
            Показан пример за сентябрь–октябрь. Можно править или начать с чистого листа.
          </p>
          <Button size="sm" variant="outline" onClick={clearAll}>
            Очистить
          </Button>
        </div>
      ) : null}
      <InstallBanner />

      <section className="grid grid-cols-2 gap-2">
        <Stat label="Выручка" value={formatMoney(monthStats.revenue)} tone="pine" />
        <Stat label="Расходы" value={formatMoney(monthStats.expenses)} tone="brick" />
      </section>

      <div className="flex gap-2 overflow-x-auto pb-1">
        <FilterChip active={month === "all"} onClick={() => setMonth("all")}>
          Все дни
        </FilterChip>
        {months.map((key) => (
          <FilterChip key={key} active={month === key} onClick={() => setMonth(key)}>
            {monthLabel(key)}
          </FilterChip>
        ))}
      </div>

      {visible.length === 0 ? (
        <EmptyState onCreate={() => openCreate()} onDemo={loadDemo} />
      ) : (
        <>
          <div className="hidden overflow-hidden rounded-xl border border-border bg-paper-raised md:block">
            <table className="w-full text-sm">
              <thead className="bg-cream/80 text-left text-fg-muted">
                <tr>
                  <th className="px-4 py-3 font-medium">Дата</th>
                  <th className="px-4 py-3 text-right font-medium">Выручка</th>
                  <th className="px-4 py-3 font-medium">Расходы</th>
                  <th className="px-4 py-3 text-right font-medium">Баланс</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((day) => (
                  <tr
                    key={day.id}
                    className="cursor-pointer border-t border-border align-top hover:bg-cream/40"
                    onClick={() => openEdit(day.id)}
                  >
                    <td className="px-4 py-3">
                      <div className="font-medium">{formatDayTitle(day.date)}</div>
                      <div className="text-xs uppercase text-fg-subtle">{formatWeekday(day.date)}</div>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums text-pine">
                      {formatMoney(day.revenue)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-right tabular-nums text-brick md:text-left">
                        {formatMoney(day.expenseTotal)}
                      </div>
                      <ul className="mt-1 space-y-0.5 text-xs text-fg-muted">
                        {day.expenses.map((expense) => (
                          <li key={expense.id} className="flex justify-between gap-3">
                            <span>
                              {CATEGORY_LABEL[expense.category]} · {expense.title}
                            </span>
                            <span className="tabular-nums">{formatMoney(expense.amount)}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                    <td
                      className={cn(
                        "px-4 py-3 text-right font-medium tabular-nums",
                        day.runningBalance < 0 ? "text-brick" : "text-fg",
                      )}
                    >
                      {formatMoney(day.runningBalance)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <ul className="space-y-2 md:hidden">
            {visible.map((day) => {
              const expanded = openId === day.id;
              return (
                <li key={day.id} className="rounded-xl border border-border bg-paper-raised p-3">
                  <button
                    type="button"
                    className="flex w-full items-start gap-3 text-left"
                    onClick={() => setOpenId(expanded ? null : day.id)}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{formatDayShort(day.date)}</p>
                        <span className="text-xs uppercase text-fg-subtle">{formatWeekday(day.date)}</span>
                      </div>
                      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
                        <div className="flex justify-between gap-2">
                          <dt className="text-fg-subtle">Выручка</dt>
                          <dd className="tabular-nums text-pine">{formatMoney(day.revenue)}</dd>
                        </div>
                        <div className="flex justify-between gap-2">
                          <dt className="text-fg-subtle">Расходы</dt>
                          <dd className="tabular-nums text-brick">{formatMoney(day.expenseTotal)}</dd>
                        </div>
                      </dl>
                    </div>
                    <div className="text-right">
                      <p className="text-[11px] uppercase tracking-wide text-fg-subtle">Баланс</p>
                      <p
                        className={cn(
                          "tabular-nums text-sm font-semibold",
                          day.runningBalance < 0 ? "text-brick" : "text-fg",
                        )}
                      >
                        {formatMoney(day.runningBalance)}
                      </p>
                      <ChevronDown
                        className={cn(
                          "ml-auto mt-1 size-4 text-fg-subtle transition-transform duration-150",
                          expanded && "rotate-180",
                        )}
                      />
                    </div>
                  </button>
                  {expanded ? (
                    <div className="mt-3 border-t border-border pt-3">
                      <p className="text-xs text-fg-subtle">
                        Итог дня {formatMoneySigned(day.dayNet)} · нарастающий с учётом прошлых дней
                      </p>
                      {day.expenses.length > 0 ? (
                        <ul className="mt-2 space-y-1.5">
                          {day.expenses.map((expense) => (
                            <li key={expense.id} className="flex items-start justify-between gap-3 text-sm">
                              <span>
                                <Badge variant={expense.category === "salary" ? "ink" : expense.category === "supplies" ? "pine" : "cream"}>
                                  {CATEGORY_LABEL[expense.category]}
                                </Badge>
                                <span className="ml-2 text-fg">{expense.title}</span>
                              </span>
                              <span className="shrink-0 tabular-nums">{formatMoney(expense.amount)}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-2 text-sm text-fg-muted">Расходов нет</p>
                      )}
                      {day.note ? <p className="mt-2 text-sm text-fg-muted">{day.note}</p> : null}
                      <Button
                        className="mt-3 w-full"
                        variant="outline"
                        onClick={() => openEdit(day.id)}
                      >
                        <Pencil />
                        Править день
                      </Button>
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ul>
        </>
      )}

      <Button className="w-full md:w-auto" variant="primary" onClick={() => openCreate()}>
        <Plus />
        Добавить день
      </Button>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "pine" | "brick";
}) {
  return (
    <div className="rounded-xl border border-border bg-paper-raised px-3 py-3">
      <p className="text-xs uppercase tracking-wide text-fg-subtle">{label}</p>
      <p className={cn("mt-1 text-lg font-semibold tabular-nums", tone === "pine" ? "text-pine" : "text-brick")}>
        {value}
      </p>
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full px-3 text-sm",
        active ? "bg-ink text-fg-on-ink" : "bg-cream text-fg-muted",
      )}
    >
      {children}
    </button>
  );
}

function monthLabel(key: string) {
  const [year, month] = key.split("-").map(Number);
  const date = new Date(year, month - 1, 1);
  return date.toLocaleDateString("ru-RU", { month: "long", year: "numeric" });
}

function EmptyState({ onCreate, onDemo }: { onCreate: () => void; onDemo: () => void }) {
  return (
    <div className="rounded-xl border border-dashed border-border bg-paper-raised px-5 py-10 text-center">
      <p className="font-display text-2xl">Книга пуста</p>
      <p className="mx-auto mt-2 max-w-sm text-sm text-fg-muted">
        Добавьте первый день: дату, выручку и расходы. Баланс будет копиться с каждым следующим днём.
      </p>
      <div className="mt-5 flex flex-col items-center gap-2 sm:flex-row sm:justify-center">
        <Button variant="primary" onClick={onCreate}>
          <Plus />
          Первый день
        </Button>
        <Button variant="outline" onClick={onDemo}>
          Показать пример
        </Button>
      </div>
    </div>
  );
}
