import { useLayoutEffect, type ReactNode } from "react";
import { STORAGE_KEY, type DayRecord } from "@/lib/ledger/types";
import { useLedgerStore } from "@/lib/ledger/store";

const SEEN_KEY = "kassa-ledger-seen";

function restoreFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as {
        state?: { days?: DayRecord[]; demo?: boolean };
      };
      if (Array.isArray(parsed.state?.days)) {
        useLedgerStore.setState({
          days: parsed.state.days,
          demo: Boolean(parsed.state.demo),
        });
        return;
      }
    }
    if (!localStorage.getItem(SEEN_KEY)) {
      useLedgerStore.getState().loadDemo();
    }
  } catch {
    /* keep empty book if storage is unreadable */
  } finally {
    localStorage.setItem(SEEN_KEY, "1");
  }
}

export function LedgerHydration({ children }: { children: ReactNode }) {
  useLayoutEffect(() => {
    restoreFromStorage();
    void useLedgerStore.persist.rehydrate();
  }, []);

  return <div data-app-ready="true">{children}</div>;
}
