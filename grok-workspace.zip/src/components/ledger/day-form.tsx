import { useEffect, useMemo, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetTitle,
} from "@/components/ui/sheet";
import { computeLedger, todayIso } from "@/lib/ledger/calc";
import { formatMoney, formatMoneySigned, newId, parseMoney, moneyToInput } from "@/lib/ledger/money";
import { useLedgerStore } from "@/lib/ledger/store";
import {
  CATEGORY_LABEL,
  EXPENSE_CATEGORIES,
  type Expense,
  type ExpenseCategory,
} from "@/lib/ledger/types";
import { cn } from "@/lib/utils";

type DraftExpense = {
  key: string;
  category: ExpenseCategory;
  title: string;
  amount: string;
};

const QUICK: Array<{ category: ExpenseCategory; title: string }> = [
  { category: "supplies", title: "Оплата поставки" },
  { category: "salary", title: "Зарплата" },
  { category: "other", title: "Аренда" },
  { category: "other", title: "Налоги" },
  { category: "other", title: "Коммунальные" },
  { category: "other", title: "Транспорт" },
];

function blankExpense(partial?: Partial<DraftExpense>): DraftExpense {
  return {
    key: newId(),
    category: "supplies",
    title: "",
    amount: "",
    ...partial,
  };
}

export function DayFormSheet() {
  const days = useLedgerStore((s) => s.days);
  const formOpen = useLedgerStore((s) => s.formOpen);
  const editingId = useLedgerStore((s) => s.editingId);
  const draftDate = useLedgerStore((s) => s.draftDate);
  const closeForm = useLedgerStore((s) => s.closeForm);
  const upsertDay = useLedgerStore((s) => s.upsertDay);
  const removeDay = useLedgerStore((s) => s.removeDay);

  const editing = days.find((day) => day.id === editingId);

  const [date, setDate] = useState(todayIso());
  const [revenue, setRevenue] = useState("");
  const [note, setNote] = useState("");
  const [expenses, setExpenses] = useState<DraftExpense[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (!formOpen) return;
    setError(null);
    setConfirmDelete(false);
    if (editing) {
      setDate(editing.date);
      setRevenue(moneyToInput(editing.revenue));
      setNote(editing.note);
      setExpenses(
        editing.expenses.map((item) => ({
          key: item.id,
          category: item.category,
          title: item.title,
          amount: moneyToInput(item.amount),
        })),
      );
      return;
    }
    setDate(draftDate || todayIso());
    setRevenue("");
    setNote("");
    setExpenses([]);
  }, [formOpen, editing, draftDate]);

  const revenueValue = parseMoney(revenue);
  const parsedExpenses = expenses.map((item) => ({
    ...item,
    parsed: parseMoney(item.amount),
  }));
  const expenseTotal = parsedExpenses.reduce(
    (sum, item) => sum + (item.parsed ?? 0),
    0,
  );
  const dayNet = (revenueValue ?? 0) - expenseTotal;

  const previewBalance = useMemo(() => {
    if (!formOpen) return 0;
    const draft: Expense[] = parsedExpenses
      .filter((item) => item.title.trim() && item.parsed !== null)
      .map((item) => ({
        id: item.key,
        category: item.category,
        title: item.title.trim(),
        amount: item.parsed ?? 0,
      }));
    const next = days.filter((day) => day.id !== editing?.id);
    next.push({
      id: editing?.id ?? "draft",
      date,
      revenue: revenueValue ?? 0,
      expenses: draft,
      note,
    });
    const computed = computeLedger(next);
    return computed.find((day) => day.date === date)?.runningBalance ?? 0;
  }, [formOpen, days, editing?.id, date, revenueValue, expenses, note, parsedExpenses]);

  const onSave = () => {
    if (revenueValue === null) {
      setError("Проверьте сумму выручки.");
      return;
    }
    const built: Expense[] = [];
    for (const item of expenses) {
      if (!item.title.trim() && !item.amount.trim()) continue;
      const amount = parseMoney(item.amount);
      if (!item.title.trim() || amount === null) {
        setError("У каждого расхода укажите название и сумму.");
        return;
      }
      built.push({
        id: item.key,
        category: item.category,
        title: item.title.trim(),
        amount,
      });
    }
    const result = upsertDay(
      { date, revenue: revenueValue, expenses: built, note: note.trim() },
      editing?.id,
    );
    if (!result.ok) {
      setError(result.error);
      return;
    }
    toast.success(editing ? "День обновлён" : "День записан");
  };

  const onDelete = () => {
    if (!editing) return;
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    removeDay(editing.id);
    toast.success("Запись удалена");
  };

  return (
    <Sheet open={formOpen} onOpenChange={(open) => (!open ? closeForm() : undefined)}>
      <SheetContent>
        <div className="flex min-h-0 flex-1 flex-col">
          <header className="px-5 pb-3 pt-4">
            <SheetTitle>{editing ? "Правка дня" : "Новый день"}</SheetTitle>
            <SheetDescription>
              Выручка, расходы и баланс считаются сразу. На одну дату — одна запись.
            </SheetDescription>
          </header>
          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-5 pb-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="day-date">Дата</Label>
                <Input
                  id="day-date"
                  type="date"
                  value={date}
                  onChange={(event) => setDate(event.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="day-revenue">Выручка, ₽</Label>
                <Input
                  id="day-revenue"
                  inputMode="decimal"
                  placeholder="0"
                  value={revenue}
                  onChange={(event) => setRevenue(event.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <Label>Расходы</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => setExpenses((list) => [...list, blankExpense()])}
                >
                  <Plus />
                  Строка
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {QUICK.map((item) => (
                  <button
                    key={item.title}
                    type="button"
                    className="h-8 rounded-full border border-border bg-paper-raised px-3 text-xs text-fg-muted"
                    onClick={() =>
                      setExpenses((list) => [...list, blankExpense(item)])
                    }
                  >
                    {item.title}
                  </button>
                ))}
              </div>
              {expenses.length === 0 ? (
                <p className="rounded-md bg-cream/70 px-3 py-3 text-sm text-fg-muted">
                  Поставки, зарплата и прочие траты — каждая отдельной строкой, с назначением.
                </p>
              ) : (
                <ul className="space-y-2">
                  {expenses.map((item) => (
                    <li
                      key={item.key}
                      className="rounded-lg border border-border bg-paper-raised p-2"
                    >
                      <div className="flex gap-2">
                        <select
                          className="h-11 min-w-0 flex-1 rounded-md border border-border bg-paper px-2 text-sm text-fg"
                          value={item.category}
                          onChange={(event) =>
                            setExpenses((list) =>
                              list.map((row) =>
                                row.key === item.key
                                  ? { ...row, category: event.target.value as ExpenseCategory }
                                  : row,
                              ),
                            )
                          }
                          aria-label="Категория расхода"
                        >
                          {EXPENSE_CATEGORIES.map((category) => (
                            <option key={category} value={category}>
                              {CATEGORY_LABEL[category]}
                            </option>
                          ))}
                        </select>
                        <Input
                          inputMode="decimal"
                          className="w-28 shrink-0"
                          placeholder="Сумма"
                          value={item.amount}
                          onChange={(event) =>
                            setExpenses((list) =>
                              list.map((row) =>
                                row.key === item.key
                                  ? { ...row, amount: event.target.value }
                                  : row,
                              ),
                            )
                          }
                          aria-label="Сумма расхода"
                        />
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          aria-label="Удалить расход"
                          onClick={() =>
                            setExpenses((list) => list.filter((row) => row.key !== item.key))
                          }
                        >
                          <Trash2 />
                        </Button>
                      </div>
                      <Input
                        className="mt-2"
                        placeholder="Назначение: поставка, ФИО, аренда…"
                        value={item.title}
                        onChange={(event) =>
                          setExpenses((list) =>
                            list.map((row) =>
                              row.key === item.key ? { ...row, title: event.target.value } : row,
                            ),
                          )
                        }
                        aria-label="Назначение расхода"
                      />
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="day-note">Заметка</Label>
              <Textarea
                id="day-note"
                rows={2}
                placeholder="Необязательно"
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </div>

            <div className="rounded-lg bg-ink px-4 py-3 text-fg-on-ink">
              <dl className="space-y-1.5 text-sm">
                <div className="flex justify-between gap-4">
                  <dt className="text-cream/70">Выручка</dt>
                  <dd className="tabular-nums">{formatMoney(revenueValue ?? 0)}</dd>
                </div>
                <div className="flex justify-between gap-4">
                  <dt className="text-cream/70">Расходы</dt>
                  <dd className="tabular-nums">{formatMoney(expenseTotal)}</dd>
                </div>
                <div className="flex justify-between gap-4 border-t border-cream/15 pt-1.5">
                  <dt>Итог дня</dt>
                  <dd
                    className={cn(
                      "tabular-nums",
                      dayNet > 0 && "text-pine-soft",
                      dayNet < 0 && "text-brick-soft",
                    )}
                  >
                    {formatMoneySigned(dayNet)}
                  </dd>
                </div>
                <div className="flex justify-between gap-4">
                  <dt>Баланс после дня</dt>
                  <dd className="font-medium tabular-nums">{formatMoney(previewBalance)}</dd>
                </div>
              </dl>
            </div>
            {error ? <p className="text-sm text-brick">{error}</p> : null}
          </div>
          <div className="flex gap-2 border-t border-border px-5 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
            {editing ? (
              <Button type="button" variant="outline" className="shrink-0" onClick={onDelete}>
                {confirmDelete ? "Удалить?" : "Удалить"}
              </Button>
            ) : null}
            <Button type="button" variant="ghost" onClick={closeForm}>
              Отмена
            </Button>
            <Button type="button" variant="primary" className="flex-1" onClick={onSave}>
              Сохранить
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
