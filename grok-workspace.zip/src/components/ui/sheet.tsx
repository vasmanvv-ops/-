import { Drawer } from "vaul";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

function Sheet({
  open,
  onOpenChange,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
}) {
  return (
    <Drawer.Root
      open={open}
      onOpenChange={onOpenChange}
      shouldScaleBackground={false}
      noBodyStyles
      modal
    >
      {open ? children : null}
    </Drawer.Root>
  );
}

function SheetContent({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <Drawer.Portal>
      <Drawer.Overlay className="fixed inset-0 z-50 bg-ink/40 no-print" />
      <Drawer.Content
        className={cn(
          "fixed bottom-0 left-0 right-0 z-50 flex max-h-[92vh] flex-col rounded-t-xl bg-paper outline-none no-print",
          className,
        )}
      >
        <div className="mx-auto mt-3 h-1 w-10 shrink-0 rounded-full bg-border" />
        {children}
      </Drawer.Content>
    </Drawer.Portal>
  );
}

function SheetTitle({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <Drawer.Title className={cn("font-display text-xl font-medium tracking-tight", className)}>
      {children}
    </Drawer.Title>
  );
}

function SheetDescription({ children }: { children: ReactNode }) {
  return <Drawer.Description className="text-sm text-fg-muted">{children}</Drawer.Description>;
}

export { Sheet, SheetContent, SheetTitle, SheetDescription };
