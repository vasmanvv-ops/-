function parseDay(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year, month - 1, day);
}

export function formatDayTitle(iso: string): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(parseDay(iso));
}

export function formatDayShort(iso: string): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "short",
  }).format(parseDay(iso));
}

export function formatWeekday(iso: string): string {
  return new Intl.DateTimeFormat("ru-RU", { weekday: "short" }).format(parseDay(iso));
}

export function formatPeriodRange(from: string, to: string): string {
  return `${formatDayTitle(from)} — ${formatDayTitle(to)}`;
}
