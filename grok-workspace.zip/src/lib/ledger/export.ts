import { formatMoney } from "./money";
import { CATEGORY_LABEL, type DayRecord } from "./types";
import { computeLedger } from "./calc";

export function ledgerToCsv(days: DayRecord[]): string {
  const rows = [
    [
      "Дата",
      "Выручка",
      "Расходы итого",
      "Итог дня",
      "Баланс нарастающим",
      "Категория расхода",
      "Назначение",
      "Сумма расхода",
      "Заметка",
    ],
  ];
  for (const day of computeLedger(days)) {
    if (day.expenses.length === 0) {
      rows.push([
        day.date,
        formatMoney(day.revenue),
        formatMoney(day.expenseTotal),
        formatMoney(day.dayNet),
        formatMoney(day.runningBalance),
        "",
        "",
        "",
        day.note,
      ]);
      continue;
    }
    day.expenses.forEach((expense, index) => {
      rows.push([
        index === 0 ? day.date : "",
        index === 0 ? formatMoney(day.revenue) : "",
        index === 0 ? formatMoney(day.expenseTotal) : "",
        index === 0 ? formatMoney(day.dayNet) : "",
        index === 0 ? formatMoney(day.runningBalance) : "",
        CATEGORY_LABEL[expense.category],
        expense.title,
        formatMoney(expense.amount),
        index === 0 ? day.note : "",
      ]);
    });
  }
  return rows
    .map((row) => row.map(csvCell).join(";"))
    .join("\n");
}

function csvCell(value: string): string {
  if (/[;"\n]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}

export function downloadText(filename: string, content: string, mime: string) {
  const blob = new Blob(["\uFEFF" + content], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function serializeLedger(days: DayRecord[]) {
  return JSON.stringify({ version: 1, days }, null, 2);
}

export function parseLedgerBackup(raw: string): DayRecord[] {
  const parsed = JSON.parse(raw) as { days?: DayRecord[] } | DayRecord[];
  const days = Array.isArray(parsed) ? parsed : parsed.days;
  if (!Array.isArray(days)) throw new Error("bad backup");
  return days.map((day) => ({
    id: String(day.id ?? crypto.randomUUID()),
    date: String(day.date),
    revenue: Number(day.revenue) || 0,
    note: String(day.note ?? ""),
    expenses: Array.isArray(day.expenses)
      ? day.expenses.map((expense) => ({
          id: String(expense.id ?? crypto.randomUUID()),
          category:
            expense.category === "supplies" || expense.category === "salary"
              ? expense.category
              : "other",
          title: String(expense.title ?? ""),
          amount: Number(expense.amount) || 0,
        }))
      : [],
  }));
}
