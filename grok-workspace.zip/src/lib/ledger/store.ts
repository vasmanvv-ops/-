import { create } from "zustand";
import { persist } from "zustand/middleware";
import { createDemoLedger } from "./seed";
import { STORAGE_KEY, type DayRecord } from "./types";

export type SaveResult = { ok: true; id: string } | { ok: false; error: string };

type LedgerState = {
  days: DayRecord[];
  demo: boolean;
  formOpen: boolean;
  editingId: string | null;
  draftDate: string | null;
  openCreate: (date?: string) => void;
  openEdit: (id: string) => void;
  closeForm: () => void;
  upsertDay: (input: Omit<DayRecord, "id">, id?: string) => SaveResult;
  removeDay: (id: string) => void;
  loadDemo: () => void;
  clearAll: () => void;
  replaceAll: (days: DayRecord[]) => SaveResult;
};

function dateTaken(days: DayRecord[], date: string, exceptId?: string) {
  return days.some((day) => day.date === date && day.id !== exceptId);
}

export const useLedgerStore = create<LedgerState>()(
  persist(
    (set, get) => ({
      days: [],
      demo: false,
      formOpen: false,
      editingId: null,
      draftDate: null,
      openCreate: (date) =>
        set({ formOpen: true, editingId: null, draftDate: date ?? null }),
      openEdit: (id) => set({ formOpen: true, editingId: id, draftDate: null }),
      closeForm: () => set({ formOpen: false, editingId: null, draftDate: null }),
      upsertDay: (input, id) => {
        const date = input.date;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
          return { ok: false, error: "Укажите корректную дату." };
        }
        if (input.revenue < 0) {
          return { ok: false, error: "Выручка не может быть отрицательной." };
        }
        if (input.expenses.some((item) => item.amount < 0 || !item.title.trim())) {
          return { ok: false, error: "У каждого расхода должно быть название и сумма." };
        }
        const { days } = get();
        if (dateTaken(days, date, id)) {
          return {
            ok: false,
            error: "На эту дату запись уже есть. Откройте её для правки.",
          };
        }
        if (id) {
          set({
            days: days.map((day) => (day.id === id ? { ...day, ...input, id } : day)),
            demo: false,
            formOpen: false,
            editingId: null,
            draftDate: null,
          });
          return { ok: true, id };
        }
        const nextId = crypto.randomUUID();
        set({
          days: [...days, { ...input, id: nextId }],
          demo: false,
          formOpen: false,
          editingId: null,
          draftDate: null,
        });
        return { ok: true, id: nextId };
      },
      removeDay: (id) =>
        set((state) => ({
          days: state.days.filter((day) => day.id !== id),
          demo: false,
          formOpen: false,
          editingId: null,
        })),
      loadDemo: () =>
        set({
          days: createDemoLedger(),
          demo: true,
          formOpen: false,
          editingId: null,
        }),
      clearAll: () =>
        set({
          days: [],
          demo: false,
          formOpen: false,
          editingId: null,
        }),
      replaceAll: (days) => {
        if (!Array.isArray(days) || days.some((day) => !day?.date || typeof day.revenue !== "number")) {
          return { ok: false, error: "Файл не похож на кассовую книгу." };
        }
        set({ days, demo: false });
        return { ok: true, id: "import" };
      },
    }),
    {
      name: STORAGE_KEY,
      skipHydration: true,
      partialize: (state) => ({
        days: state.days,
        demo: state.demo,
      }),
    },
  ),
);
