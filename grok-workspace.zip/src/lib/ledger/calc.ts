import type {
  CategoryTotals,
  DayComputed,
  DayRecord,
  Expense,
  PeriodReport,
} from "./types";

export function sumExpenses(expenses: Expense[]): number {
  return expenses.reduce((sum, item) => sum + item.amount, 0);
}

export function computeLedger(days: DayRecord[]): DayComputed[] {
  const sorted = [...days].sort((a, b) => a.date.localeCompare(b.date));
  let running = 0;
  return sorted.map((day) => {
    const expenseTotal = sumExpenses(day.expenses);
    const dayNet = day.revenue - expenseTotal;
    running += dayNet;
    return { ...day, expenseTotal, dayNet, runningBalance: running };
  });
}

export function emptyCategoryTotals(): CategoryTotals {
  return { supplies: 0, salary: 0, other: 0 };
}

export function reportForPeriod(
  days: DayRecord[],
  from: string,
  to: string,
): PeriodReport {
  const start = from <= to ? from : to;
  const end = from <= to ? to : from;
  const computed = computeLedger(days);
  const before = computed.filter((day) => day.date < start);
  const inRange = computed.filter((day) => day.date >= start && day.date <= end);
  const opening = before.at(-1)?.runningBalance ?? 0;
  const revenue = inRange.reduce((sum, day) => sum + day.revenue, 0);
  const expenses = inRange.flatMap((day) =>
    day.expenses.map((expense) => ({ ...expense, date: day.date })),
  );
  const expenseSum = expenses.reduce((sum, item) => sum + item.amount, 0);
  const byCategory = emptyCategoryTotals();
  for (const expense of expenses) {
    byCategory[expense.category] += expense.amount;
  }
  const net = revenue - expenseSum;
  const closing = inRange.at(-1)?.runningBalance ?? opening;
  return {
    from: start,
    to: end,
    opening,
    revenue,
    expenseSum,
    byCategory,
    expenses,
    net,
    closing,
    days: inRange,
  };
}

export function monthBounds(isoDate: string): { from: string; to: string } {
  const [year, month] = isoDate.split("-").map(Number);
  const last = new Date(year, month, 0).getDate();
  const pad = (value: number) => String(value).padStart(2, "0");
  return {
    from: `${year}-${pad(month)}-01`,
    to: `${year}-${pad(month)}-${pad(last)}`,
  };
}

export function todayIso(now = new Date()): string {
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}
