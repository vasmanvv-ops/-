export const EXPENSE_CATEGORIES = ["supplies", "salary", "other"] as const;

export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];

export type Expense = {
  id: string;
  category: ExpenseCategory;
  title: string;
  amount: number;
};

export type DayRecord = {
  id: string;
  date: string;
  revenue: number;
  expenses: Expense[];
  note: string;
};

export type DayComputed = DayRecord & {
  expenseTotal: number;
  dayNet: number;
  runningBalance: number;
};

export type CategoryTotals = Record<ExpenseCategory, number>;

export type PeriodReport = {
  from: string;
  to: string;
  opening: number;
  revenue: number;
  expenseSum: number;
  byCategory: CategoryTotals;
  expenses: Array<Expense & { date: string }>;
  net: number;
  closing: number;
  days: DayComputed[];
};

export const CATEGORY_LABEL: Record<ExpenseCategory, string> = {
  supplies: "Поставки",
  salary: "Зарплата",
  other: "Прочее",
};

export const STORAGE_KEY = "kassa-ledger-v1";
