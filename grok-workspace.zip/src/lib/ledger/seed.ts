import type { DayRecord, Expense, ExpenseCategory } from "./types";
import { newId } from "./money";

function rub(value: number): number {
  return Math.round(value * 100);
}

function expense(
  category: ExpenseCategory,
  title: string,
  amount: number,
): Expense {
  return { id: newId(), category, title, amount: rub(amount) };
}

function day(
  date: string,
  revenue: number,
  expenses: Expense[],
  note = "",
): DayRecord {
  return { id: newId(), date, revenue: rub(revenue), expenses, note };
}

export function createDemoLedger(): DayRecord[] {
  return [
    day("2026-09-15", 48600, [
      expense("supplies", "Мука, масло, дрожжи", 12400),
      expense("other", "Аренда за сентябрь", 18000),
      expense("other", "Коммунальные услуги", 4200),
    ]),
    day("2026-09-16", 31250, [
      expense("supplies", "Молоко и яйца", 6800),
      expense("other", "Доставка сырья", 1500),
    ]),
    day("2026-09-17", 35800, [
      expense("salary", "Аванс пекарю", 12000),
      expense("supplies", "Упаковка и пакеты", 2100),
    ]),
    day("2026-09-18", 27400, [
      expense("supplies", "Начинки и ягоды", 5400),
    ]),
    day("2026-09-19", 52100, [
      expense("supplies", "Пятничная поставка", 9800),
      expense("other", "Ремонт витрины", 3500),
    ]),
    day("2026-09-20", 61400, [
      expense("salary", "Выходные продавцам", 16000),
      expense("supplies", "Кофе и чай", 4300),
    ]),
    day("2026-09-22", 19800, [
      expense("other", "Налог УСН", 8500),
    ]),
    day("2026-09-23", 33600, [
      expense("supplies", "Овощи и зелень", 4100),
      expense("other", "Хозтовары", 900),
    ]),
    day("2026-09-25", 40250, [
      expense("salary", "Зарплата кассиру", 18000),
      expense("supplies", "Молочная продукция", 7200),
    ]),
    day("2026-09-27", 28900, [
      expense("supplies", "Хлебные смеси", 3600),
    ]),
    day("2026-09-29", 45700, [
      expense("other", "Реклама в соцсетях", 2500),
      expense("supplies", "Шоколад и орехи", 6100),
    ]),
    day("2026-09-30", 53800, [
      expense("salary", "Расчёт за сентябрь", 22000),
      expense("other", "Связь и эквайринг", 1800),
    ]),
    day("2026-10-01", 36400, [
      expense("supplies", "Октябрьская поставка", 11200),
      expense("other", "Аренда за октябрь", 18000),
    ]),
    day("2026-10-02", 41200, [
      expense("supplies", "Фрукты к выпечке", 4700),
      expense("other", "Бензин", 2200),
    ]),
    day("2026-10-03", 29750, [
      expense("salary", "Подработка грузчика", 4500),
    ], "Короткий день, утренние заказы"),
  ];
}
