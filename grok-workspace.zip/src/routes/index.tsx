import { createFileRoute } from "@tanstack/react-router";
import { Journal } from "@/components/ledger/journal";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Journal />;
}
