import { createFileRoute } from "@tanstack/react-router";
import { ReportView } from "@/components/ledger/report-view";

export const Route = createFileRoute("/report")({ component: ReportPage });

function ReportPage() {
  return <ReportView />;
}
